function keyDownListener(event) {
    const img = document.createElement("img");
    const body = document.getElementsByTagName("body")[0];
    switch(event.key) {
        case 's':
            img.setAttribute('src', 'resources/images/bubble-1.png');
            break;
        default:
            return;
    }

    let bodyWidth = parseInt(window.getComputedStyle(body).getPropertyValue('width'));
    let bodyHeight = parseInt(window.getComputedStyle(body).getPropertyValue('height'));
    bodyWidth -= 500;
    bodyHeight -= 500; // evitam afisarea unei bule pe marginea ecranului
    let top = Math.floor(Math.random()*bodyHeight);
    let left = Math.floor(Math.random()*bodyWidth);
    top = top.toString();
    left = left.toString();

    body.style.position = "relative";
    body.style.display = "block";
    img.style.display = "inline-block";
    img.style.position = "absolute";
    img.style.top = top + "px";
    img.style.left = left + "px";

    img.addEventListener("click", clickListener);

    body.appendChild(img);
}

function clickListener(event) {
    setTimeout(() => { 
        event.target.setAttribute('src', 'resources/images/bubble-2.png');
    }, 100);
    setTimeout(() => { 
        event.target.setAttribute('src', 'resources/images/bubble-3.png');
    }, 1000);
    setTimeout(() => { 
        event.target.setAttribute('src', 'resources/images/bubble-4.png');
    }, 1500);
    setTimeout(() => { 
        event.target.style.display = "none";
    }, 2000);

    let bubbles = Number(sessionStorage.getItem("bubbles"));
    if (bubbles) {
      sessionStorage.setItem("bubbles", bubbles + 1); 
    }
    else {
      sessionStorage.setItem("bubbles", "1"); 
    }
    const p = document.getElementById("bubbles");
    p.innerHTML = sessionStorage.getItem("bubbles");
}

window.onload = function() {
    const body = document.getElementsByTagName("body")[0];
    const p = document.createElement("p");
    
    p.style.textAlign = "right";
    p.style.color = "white";
    p.style.fontSize = "40px";
    p.setAttribute('id', 'bubbles');
    body.style.overflow = "hidden"; // vrem sa evitam scroll-ul orizontal pe cat posibil, e o preferinta personala, se poate sterge linia oricand

    body.appendChild(p);

    document.body.addEventListener('keydown', keyDownListener);
}
